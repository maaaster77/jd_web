
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "https",
                    host: "pr.oxylabs.io",
                    port: parseInt(7777)
                  },
                  bypassList: ["foobar.com"]
                }
              };
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "customer-hunyun__wgIH3-sessid-0008875723-sesstime-10",
                    password: "Wasd12345678+"
                }
            };
        }
        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        